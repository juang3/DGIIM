# DGIIM
Contiene: teoría, ejercicios y practicas de las asignaturas

18 04 2018] Incluida la práctica_2 (p2) de Sistemas Gráficos (SG)
